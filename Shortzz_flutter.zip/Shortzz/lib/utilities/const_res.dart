const String baseURL = 'your_base_url';
const String apiURL = '${baseURL}api/';
const String apiKey = 'retry123';

String notificationTopic = "shortzz";

String revenueCatAndroidApiKey = "your_revenueCat_android_api_key";
String revenueCatAppleApiKey = "your_revenueCat_iOS_api_key";

