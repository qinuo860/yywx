class FontRes {
  static const String outFitBlack900 = 'Black';
  static const String outFitExtraBold800 = 'ExtraBold';
  static const String outFitBold700 = 'Bold';
  static const String outFitSemiBold600 = 'SemiBold';
  static const String outFitMedium500 = 'Medium';
  static const String outFitRegular400 = 'Regular';
  static const String outFitLight300 = 'Light';
  static const String outFitExtraLight200 = 'ExtraLight';
  static const String outFitThin100 = 'Thin';
  static const String unboundedBlack900 = 'Unbounded-Black';
  static const String unboundedBold700 = 'Unbounded-Bold';
  static const String unboundedExtraBold800 = 'Unbounded-ExtraBold';
  static const String unboundedExtraLight100 = 'Unbounded-ExtraLight';
  static const String unboundedLight200 = 'Unbounded-Light';
  static const String unboundedMedium500 = 'Unbounded-Medium';
  static const String unboundedRegular400 = 'Unbounded-Regular';
  static const String unboundedSemiBold600 = 'Unbounded-SemiBold';
}
