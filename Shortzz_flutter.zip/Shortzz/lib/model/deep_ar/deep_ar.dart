

class DeepAr {
  String filter;
  String preview;
  String name;

  DeepAr(this.filter, this.preview, this.name);
}

